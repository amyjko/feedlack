#!/bin/bash

start=`pwd`

echo "Beautifying project " $1

declare -a FILES
count=0

recurseThroughFolder () 
{ 

    # Enter this directory
    cd "$1"

	local cwd=`pwd`

    # Go through all of the files in this directory
    for d in *
    do
      # Does this file end with ".js"?
      if [[ $d =~ .*\.js ]]; then
		FILES[$count]=$cwd/$d
		count=$(($count+1))
      fi;
      if [ -d "$d" ]; then
          recurseThroughFolder "$d"
      fi;
    done

	cd "$cwd"
    
}

start=`pwd`

# Start on the given folder
recurseThroughFolder $1

cd "$start"

for file in ${FILES[@]}; do
	echo "Beautifying" $file
	java -jar js.jar beautify-cl.js $file > $file.pretty
	rm $file
	mv $file.pretty $file
done

exit


